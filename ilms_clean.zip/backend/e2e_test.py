import json
import urllib.request

BASE = 'http://127.0.0.1:8000/api/'

headers = {'Content-Type': 'application/json'}

def post(path, data, token=None):
    data = json.dumps(data).encode('utf-8')
    h = headers.copy()
    if token:
        h['Authorization'] = f'Bearer {token}'
    req = urllib.request.Request(BASE+path, data=data, headers=h)
    try:
        with urllib.request.urlopen(req) as resp:
            return resp.status, json.load(resp)
    except urllib.error.HTTPError as e:
        try:
            body = e.read().decode()
            return e.code, json.loads(body)
        except Exception:
            return e.code, {'error': str(e)}

def get(path, token=None):
    h = headers.copy()
    if token:
        h['Authorization'] = f'Bearer {token}'
    req = urllib.request.Request(BASE+path, headers=h)
    try:
        with urllib.request.urlopen(req) as resp:
            return resp.status, json.load(resp)
    except urllib.error.HTTPError as e:
        try:
            body = e.read().decode()
            return e.code, json.loads(body)
        except Exception:
            return e.code, {'error': str(e)}

if __name__ == '__main__':
    print('Starting E2E test')
    # Register agent
    agent = {'username':'agent1','first_name':'Agent One','email':'agent1@example.com','password':'StrongPass123!','role':'agent'}
    status, res = post('register/', agent)
    print('Register agent:', status, res)

    # Register client
    client = {'username':'client1','first_name':'Client One','email':'client1@example.com','password':'StrongPass123!','role':'client'}
    status, res = post('register/', client)
    print('Register client:', status, res)

    # Login agent
    status, res = post('login/', {'email': agent['email'], 'password': agent['password']})
    print('Login agent:', status, res)
    agent_token = res.get('token') if isinstance(res, dict) else None

    # Login client
    status, res = post('login/', {'email': client['email'], 'password': client['password']})
    print('Login client:', status, res)
    client_token = res.get('token') if isinstance(res, dict) else None

    # Agent creates a product
    product = {'type':'insurance','name':'Test Insurance','description':'Test desc','price':'199.99'}
    status, res = post('products/', product, token=agent_token)
    print('Create product:', status, res)
    product_id = res.get('id') if isinstance(res, dict) else None

    # Client lists products
    status, res = get('products/', token=client_token)
    print('List products (client):', status, res)

    # Client creates a request for product
    if product_id:
        status, res = post('requests/', {'product': product_id, 'note':'Please approve'}, token=client_token)
        print('Create request:', status, res)
        request_id = res.get('id') if isinstance(res, dict) else None
    else:
        print('No product id, skipping request creation')
        request_id = None

    # Agent lists requests
    status, res = get('requests/', token=agent_token)
    print('List requests (agent):', status, res)

    # Agent approves request
    if request_id:
        # Use PATCH to update status
        def patch(path, data, token=None):
            data = json.dumps(data).encode('utf-8')
            h = headers.copy()
            if token:
                h['Authorization'] = f'Bearer {token}'
            req = urllib.request.Request(BASE+path, data=data, headers=h, method='PATCH')
            try:
                with urllib.request.urlopen(req) as resp:
                    return resp.status, json.load(resp)
            except urllib.error.HTTPError as e:
                try:
                    body = e.read().decode()
                    return e.code, json.loads(body)
                except Exception:
                    return e.code, {'error': str(e)}

        status, res = patch(f'requests/{request_id}/', {'status':'APPROVED'}, token=agent_token)
        print('Update request status:', status, res)
    else:
        print('No request id to approve')

    print('E2E test completed')

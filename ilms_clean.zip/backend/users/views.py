from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth.models import Group, User
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken
from .serializers import RegisterSerializer


class RegisterView(generics.CreateAPIView):
    serializer_class = RegisterSerializer

    def post(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            # Create user role groups if they don't exist
            Group.objects.get_or_create(name='client')
            Group.objects.get_or_create(name='agent')
            # Create the user
            user = serializer.save()
            return Response({
                "message": "User registered successfully",
                "user": {
                    "id": user.id,
                    "username": user.username,
                    "email": user.email,
                    "role": user.groups.first().name if user.groups.exists() else None
                }
            }, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class LoginView(APIView):
    """Login using username or email. Returns access token as 'token' and refresh token."""
    def post(self, request, *args, **kwargs):
        import traceback
        try:
            username = request.data.get('username')
            email = request.data.get('email')
            password = request.data.get('password')

            user = None
            if username:
                user = authenticate(request, username=username, password=password)
            elif email:
                try:
                    u = User.objects.get(email=email)
                    user = authenticate(request, username=u.username, password=password)
                except User.DoesNotExist:
                    user = None

            if user is None:
                return Response({"detail": "Invalid credentials"}, status=status.HTTP_401_UNAUTHORIZED)

            refresh = RefreshToken.for_user(user)
            role = user.groups.first().name if user.groups.exists() else None

            return Response({
                'token': str(refresh.access_token),
                'refresh': str(refresh),
                'username': user.username,
                'role': role,
            }, status=status.HTTP_200_OK)
        except Exception as e:
            tb = traceback.format_exc()
            return Response({"detail": str(e), "trace": tb}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

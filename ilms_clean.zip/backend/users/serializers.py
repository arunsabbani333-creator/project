from rest_framework import serializers
from django.contrib.auth.models import User, Group
from django.contrib.auth.password_validation import validate_password
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer


class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=True, validators=[validate_password])
    # Use (value, label) tuples for choices to be explicit
    role = serializers.ChoiceField(choices=(('client', 'client'), ('agent', 'agent')), required=True)

    class Meta:
        model = User
        fields = ('username', 'email', 'password', 'first_name', 'role')

    def create(self, validated_data):
        # Extract role name and create user
        role_name = validated_data.pop('role')
        user = User.objects.create_user(**validated_data)

        # Ensure the Group exists and add the user to that group
        group, _ = Group.objects.get_or_create(name=role_name)
        user.groups.add(group)
        return user


class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    def validate(self, attrs):
        data = super().validate(attrs)
        data['username'] = self.user.username
        data['role'] = self.user.groups.first().name if self.user.groups.exists() else None
        return data
import json
import urllib.request
url = 'http://127.0.0.1:8000/api/login/'
data = json.dumps({'email':'arunsabbani333@gmail.com','password':'StrongPass123!'}).encode('utf-8')
req = urllib.request.Request(url, data=data, headers={'Content-Type':'application/json'})
resp = urllib.request.urlopen(req)
print(resp.status)
print(resp.read().decode())

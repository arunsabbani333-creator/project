from rest_framework import serializers
from .models import Request


class RequestSerializer(serializers.ModelSerializer):
    product = serializers.PrimaryKeyRelatedField(queryset=None)

    class Meta:
        model = Request
        fields = ('id', 'client', 'product', 'note', 'status', 'created_at')
        read_only_fields = ('id', 'client', 'created_at')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # set queryset lazily to avoid import cycle
        from products.models import Product
        self.fields['product'].queryset = Product.objects.all()

    def create(self, validated_data):
        request = self.context.get('request')
        if request and request.user and request.user.is_authenticated:
            validated_data['client'] = request.user
        return super().create(validated_data)

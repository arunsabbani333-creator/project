from rest_framework import viewsets, permissions
from .models import Request as ProductRequest
from .serializers import RequestSerializer


class IsClientOrAgent(permissions.BasePermission):
	def has_permission(self, request, view):
		# Clients can create and view their own requests; agents can view/update
		return request.user and request.user.is_authenticated

	def has_object_permission(self, request, view, obj):
		if request.user.groups.filter(name='agent').exists():
			return True
		return obj.client == request.user


class RequestViewSet(viewsets.ModelViewSet):
	queryset = ProductRequest.objects.all().order_by('-created_at')
	serializer_class = RequestSerializer
	permission_classes = [IsClientOrAgent]

	def get_queryset(self):
		user = self.request.user
		if user.groups.filter(name='agent').exists():
			return ProductRequest.objects.all().order_by('-created_at')
		return ProductRequest.objects.filter(client=user).order_by('-created_at')


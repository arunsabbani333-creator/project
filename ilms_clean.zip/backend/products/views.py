from rest_framework import viewsets, permissions
from .models import Product
from .serializers import ProductSerializer


class IsAgent(permissions.BasePermission):
	def has_permission(self, request, view):
		# Allow safe methods for everyone, but restrict write operations to agents
		if request.method in permissions.SAFE_METHODS:
			return True
		return request.user and request.user.groups.filter(name='agent').exists()


class ProductViewSet(viewsets.ModelViewSet):
	queryset = Product.objects.all().order_by('-created_at')
	serializer_class = ProductSerializer
	permission_classes = [IsAgent]


# product_requests app package (renamed to avoid conflict with the 'requests' PyPI package)

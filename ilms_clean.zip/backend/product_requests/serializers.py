from rest_framework import serializers
from .models import Request


class RequestSerializer(serializers.ModelSerializer):
    # We'll set up nested product serialization lazily to avoid import-time cycles

    class Meta:
        model = Request
        # include a write-only 'product_id' so clients can POST/ PATCH using an id
        fields = ('id', 'client', 'product', 'product_id', 'note', 'status', 'created_at')
        read_only_fields = ('id', 'client', 'created_at')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # set fields lazily to avoid import cycles
        from products.models import Product
        from products.serializers import ProductSerializer

        # product: nested read-only representation
        self.fields['product'] = ProductSerializer(read_only=True)

        # product_id: write-only field used for creating/updating requests
        self.fields['product_id'] = serializers.PrimaryKeyRelatedField(write_only=True, source='product', queryset=Product.objects.all())

    def create(self, validated_data):
        request = self.context.get('request')
        if request and request.user and request.user.is_authenticated:
            validated_data['client'] = request.user
        return super().create(validated_data)

    def update(self, instance, validated_data):
        # allow partial updates (e.g., status) while preserving nested product representation
        return super().update(instance, validated_data)

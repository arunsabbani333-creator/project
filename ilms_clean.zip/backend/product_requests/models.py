from django.db import models
from django.contrib.auth.models import User
from products.models import Product


class Request(models.Model):
    STATUS_CHOICES = (
        ('PENDING', 'Pending'),
        ('APPROVED', 'Approved'),
        ('REJECTED', 'Rejected'),
    )

    client = models.ForeignKey(User, related_name='requests', on_delete=models.CASCADE)
    product = models.ForeignKey(Product, related_name='requests', on_delete=models.CASCADE)
    note = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='PENDING')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Request {self.id} - {self.product.name} ({self.status})"

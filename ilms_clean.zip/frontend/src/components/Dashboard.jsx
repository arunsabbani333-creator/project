import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/main.css';

function Dashboard() {
  const [userRole, setUserRole] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const role = localStorage.getItem('userRole');
    if (!role) {
      navigate('/login');
    }
    setUserRole(role);
  }, [navigate]);

  const handleNavigation = (path) => {
    navigate(path);
  };

  return (
    <div className="container">
      <div className="card">
        <h2>Welcome to FinBridge</h2>
        <p>You are logged in as: {userRole}</p>
        
        <div className="grid" style={{ marginTop: '2rem' }}>
          {userRole === 'client' && (
            <>
              <div className="card">
                <h3>Insurance</h3>
                <p>Browse and apply for insurance products</p>
                <button
                  className="btn btn-primary"
                  onClick={() => handleNavigation('/products?type=insurance')}
                >
                  View Insurance Products
                </button>
              </div>
              
              <div className="card">
                <h3>Loans</h3>
                <p>Browse and apply for loan products</p>
                <button
                  className="btn btn-primary"
                  onClick={() => handleNavigation('/products?type=loan')}
                >
                  View Loan Products
                </button>
              </div>
              
              <div className="card">
                <h3>My Requests</h3>
                <p>View your application status</p>
                <button
                  className="btn btn-primary"
                  onClick={() => handleNavigation('/requests')}
                >
                  View My Requests
                </button>
              </div>
            </>
          )}
          
          {userRole === 'agent' && (
            <>
              <div className="card">
                <h3>Manage Products</h3>
                <p>Add, edit, or remove products</p>
                <button
                  className="btn btn-primary"
                  onClick={() => handleNavigation('/products/manage')}
                >
                  Manage Products
                </button>
              </div>
              
              <div className="card">
                <h3>Pending Requests</h3>
                <p>Review and process customer requests</p>
                <button
                  className="btn btn-primary"
                  onClick={() => handleNavigation('/requests')}
                >
                  View Requests
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
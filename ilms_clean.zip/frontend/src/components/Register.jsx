import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { register } from '../api';
import '../styles/main.css';

function Register() {
  const [formData, setFormData] = useState({
     username: '',
    email: '',
    password: '',
     first_name: '',
    role: 'client'
  });
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await register(formData);
      navigate('/login');
    } catch (err) {
      // Format server validation errors into a readable string
      const data = err.response?.data;
      if (!data) {
        setError('Registration failed');
        return;
      }

      if (typeof data === 'string') {
        setError(data);
        return;
      }

      // If DRF returns a dict of field errors, join them
      const messages = Object.entries(data).map(([key, val]) => {
        const text = Array.isArray(val) ? val.join(' ') : String(val);
        return `${key}: ${text}`;
      }).join(' | ');
      setError(messages || 'Registration failed');
    }
  };

  return (
    <div className="container">
      <div className="card" style={{ maxWidth: '400px', margin: '2rem auto' }}>
        <h2 style={{ textAlign: 'center', marginBottom: '2rem' }}>Register</h2>
        
        {error && <div className="alert alert-error">{error}</div>}
        
        <form onSubmit={handleSubmit}>
          <div className="form-group">
              <label className="form-label">Username</label>
            <input
              type="text"
                name="username"
                className="form-input"
                value={formData.username}
                onChange={handleChange}
                required
              />
            </div>
          
            <div className="form-group">
              <label className="form-label">Full Name</label>
              <input
                type="text"
                name="first_name"
              className="form-input"
                value={formData.first_name}
              onChange={handleChange}
              required
            />
          </div>
          
          <div className="form-group">
            <label className="form-label">Email</label>
            <input
              type="email"
              name="email"
              className="form-input"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </div>
          
          <div className="form-group">
            <label className="form-label">Password</label>
            <input
              type="password"
              name="password"
              className="form-input"
              value={formData.password}
              onChange={handleChange}
              required
            />
          </div>
          
          <div className="form-group">
            <label className="form-label">Role</label>
            <select
              name="role"
              className="form-input"
              value={formData.role}
              onChange={handleChange}
              required
            >
              <option value="client">Client</option>
              <option value="agent">Agent</option>
            </select>
          </div>
          
          <button type="submit" className="btn btn-primary" style={{ width: '100%' }}>
            Register
          </button>
        </form>
      </div>
    </div>
  );
}

export default Register;
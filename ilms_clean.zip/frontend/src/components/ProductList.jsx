import { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { getProducts, createProduct, deleteProduct, createRequest } from '../api';
import '../styles/main.css';

function ProductList() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [userRole] = useState(localStorage.getItem('userRole'));
  const [newProduct, setNewProduct] = useState({ name: '', description: '', price: '', type: 'insurance' });
  
  const location = useLocation();
  const navigate = useNavigate();
  const searchParams = new URLSearchParams(location.search);
  const filterType = searchParams.get('type');

  useEffect(() => {
    fetchProducts();
    const interval = setInterval(fetchProducts, 5000); // Poll every 5 seconds
    return () => clearInterval(interval);
  }, []);

  const fetchProducts = async () => {
    try {
      const response = await getProducts();
      let filteredProducts = response.data;
      if (filterType) {
        filteredProducts = filteredProducts.filter(p => p.type === filterType);
      }
      setProducts(filteredProducts);
      setLoading(false);
    } catch (err) {
      setError('Failed to load products');
      setLoading(false);
    }
  };

  const handleCreateProduct = async (e) => {
    e.preventDefault();
    try {
      await createProduct(newProduct);
      setNewProduct({ name: '', description: '', price: '', type: 'insurance' });
      fetchProducts();
    } catch (err) {
      setError('Failed to create product');
    }
  };

  const handleDeleteProduct = async (id) => {
    try {
      await deleteProduct(id);
      fetchProducts();
    } catch (err) {
      setError('Failed to delete product');
    }
  };

  const handleCreateRequest = async (productId) => {
    try {
      await createRequest({
        product_id: productId,
        note: 'Interested in this product'
      });
      navigate('/requests');
    } catch (err) {
      setError('Failed to create request');
    }
  };

  if (loading) {
    return <div className="spinner"></div>;
  }

  return (
    <div className="container">
      {error && <div className="alert alert-error">{error}</div>}
      
      {userRole === 'agent' && (
        <div className="card">
          <h3>Add New Product</h3>
          <form onSubmit={handleCreateProduct}>
            <div className="form-group">
              <label className="form-label">Name</label>
              <input
                type="text"
                className="form-input"
                value={newProduct.name}
                onChange={(e) => setNewProduct({...newProduct, name: e.target.value})}
                required
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Description</label>
              <textarea
                className="form-input"
                value={newProduct.description}
                onChange={(e) => setNewProduct({...newProduct, description: e.target.value})}
                required
              ></textarea>
            </div>
            
            <div className="form-group">
              <label className="form-label">Price</label>
              <input
                type="number"
                className="form-input"
                value={newProduct.price}
                onChange={(e) => setNewProduct({...newProduct, price: e.target.value})}
                required
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Type</label>
              <select
                className="form-input"
                value={newProduct.type}
                onChange={(e) => setNewProduct({...newProduct, type: e.target.value})}
                required
              >
                <option value="insurance">Insurance</option>
                <option value="loan">Loan</option>
              </select>
            </div>
            
            <button type="submit" className="btn btn-primary">Add Product</button>
          </form>
        </div>
      )}
      
      <div className="grid">
        {products.map(product => (
          <div key={product.id} className="card">
            <h3>{product.name}</h3>
            <p>{product.description}</p>
            <p><strong>Price:</strong> ${product.price}</p>
            <p><strong>Type:</strong> {product.type}</p>
            
            {userRole === 'client' ? (
              <button
                className="btn btn-primary"
                onClick={() => handleCreateRequest(product.id)}
              >
                Request Product
              </button>
            ) : (
              <button
                className="btn btn-danger"
                onClick={() => handleDeleteProduct(product.id)}
              >
                Delete Product
              </button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

export default ProductList;
import { useState, useEffect } from 'react';
import { getRequests, updateRequestStatus } from '../api';
import '../styles/main.css';

function RequestList() {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [userRole] = useState(localStorage.getItem('userRole'));

  useEffect(() => {
    fetchRequests();
    const interval = setInterval(fetchRequests, 5000); // Poll every 5 seconds
    return () => clearInterval(interval);
  }, []);

  const fetchRequests = async () => {
    try {
      const response = await getRequests();
      setRequests(response.data);
      setLoading(false);
    } catch (err) {
      setError('Failed to load requests');
      setLoading(false);
    }
  };

  const handleUpdateStatus = async (id, status) => {
    try {
      await updateRequestStatus(id, status);
      fetchRequests();
    } catch (err) {
      setError('Failed to update request status');
    }
  };

  const getStatusBadgeClass = (status) => {
    switch (status) {
      case 'PENDING':
        return 'badge badge-pending';
      case 'APPROVED':
        return 'badge badge-approved';
      case 'REJECTED':
        return 'badge badge-rejected';
      default:
        return 'badge';
    }
  };

  if (loading) {
    return <div className="spinner"></div>;
  }

  return (
    <div className="container">
      {error && <div className="alert alert-error">{error}</div>}
      
      <div className="card">
        <h2>{userRole === 'agent' ? 'All Requests' : 'My Requests'}</h2>
        
        <ul className="list">
          {requests.map(request => (
            <li key={request.id} className="list-item" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <h3>{request.product.name}</h3>
                <p>Type: {request.product.type}</p>
                <p>Note: {request.note}</p>
                <span className={getStatusBadgeClass(request.status)}>
                  {request.status}
                </span>
              </div>
              
              {userRole === 'agent' && request.status === 'PENDING' && (
                <div style={{ display: 'flex', gap: '0.5rem' }}>
                  <button
                    className="btn btn-success"
                    onClick={() => handleUpdateStatus(request.id, 'APPROVED')}
                  >
                    Approve
                  </button>
                  <button
                    className="btn btn-danger"
                    onClick={() => handleUpdateStatus(request.id, 'REJECTED')}
                  >
                    Reject
                  </button>
                </div>
              )}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default RequestList;
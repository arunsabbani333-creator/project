import axios from 'axios';

const api = axios.create({
  baseURL: 'http://localhost:8000/api/',
});

// Add JWT token to requests if it exists
api.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Auth services
export const register = (userData) => api.post('/register/', userData);
export const login = (credentials) => api.post('/login/', credentials);

// Product services
export const getProducts = () => api.get('/products/');
export const createProduct = (productData) => api.post('/products/', productData);
export const updateProduct = (id, productData) => api.put(`/products/${id}/`, productData);
export const deleteProduct = (id) => api.delete(`/products/${id}/`);

// Request services
export const getRequests = () => api.get('/requests/');
export const createRequest = (requestData) => api.post('/requests/', requestData);
export const updateRequestStatus = (id, status) => api.patch(`/requests/${id}/`, { status });

export default api;
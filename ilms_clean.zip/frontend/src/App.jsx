import { BrowserRouter as Router, Routes, Route, Link, Navigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import Login from './components/Login';
import Register from './components/Register';
import Dashboard from './components/Dashboard';
import ProductList from './components/ProductList';
import RequestList from './components/RequestList';
import './styles/main.css';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('token');
    setIsAuthenticated(!!token);
    // listen for storage changes (other tabs) and custom authChange events
    const onStorage = () => setIsAuthenticated(!!localStorage.getItem('token'));
    const onAuthChange = () => setIsAuthenticated(!!localStorage.getItem('token'));
    window.addEventListener('storage', onStorage);
    window.addEventListener('authChange', onAuthChange);
    return () => {
      window.removeEventListener('storage', onStorage);
      window.removeEventListener('authChange', onAuthChange);
    };
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('userRole');
    setIsAuthenticated(false);
    // notify other parts of the app
    window.dispatchEvent(new Event('authChange'));
  };

  return (
    <Router>
      <div className="app">
        <nav className="nav">
          <div className="container">
            <ul className="nav-list">
            {isAuthenticated ? (
              <>
                <li>
                  <Link to="/dashboard" className="nav-link">Dashboard</Link>
                </li>
                <li>
                  <Link to="/products" className="nav-link">Products</Link>
                </li>
                <li>
                  <Link to="/requests" className="nav-link">Requests</Link>
                </li>
                <li>
                  <button onClick={handleLogout} className="btn btn-danger">
                    Logout
                  </button>
                </li>
              </>
            ) : (
              <>
                <li>
                  <Link to="/login" className="nav-link">Login</Link>
                </li>
                <li>
                  <Link to="/register" className="nav-link">Register</Link>
                </li>
              </>
            )}
            </ul>
          </div>
        </nav>

        <main className="main">
          <div className="container">
            <Routes>
              <Route path="/login" element={
                !isAuthenticated ? <Login /> : <Navigate to="/dashboard" />
              } />
              <Route path="/register" element={
                !isAuthenticated ? <Register /> : <Navigate to="/dashboard" />
              } />
              <Route path="/dashboard" element={
                isAuthenticated ? <Dashboard /> : <Navigate to="/login" />
              } />
              <Route path="/products" element={
                isAuthenticated ? <ProductList /> : <Navigate to="/login" />
              } />
              <Route path="/products/manage" element={
                isAuthenticated ? <ProductList /> : <Navigate to="/login" />
              } />
              <Route path="/requests" element={
                isAuthenticated ? <RequestList /> : <Navigate to="/login" />
              } />
              <Route path="/" element={<Navigate to={isAuthenticated ? "/dashboard" : "/login"} />} />
            </Routes>
          </div>
        </main>

      </div>
    </Router>
  );
}

export default App;

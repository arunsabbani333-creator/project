# ILMS — Insurance & Loan Management System

This repo is organized for **beginners** with a clear split:

```
backend/   # Django app
frontend/  # React + Vite app (JavaScript)
```

## Quickstart

### 1) Backend (Django)

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt  # if present
# If no requirements.txt is present:
pip install django djangorestframework corsheaders
python manage.py migrate
python manage.py runserver
```

### 2) Frontend (React + Vite, JS)

```bash
cd frontend
npm install
npm run dev
```

> Default Vite dev server: http://localhost:5173

### 3) CORS (connect frontend ↔ backend)
- Add `corsheaders` to Django `INSTALLED_APPS` and middleware.
- Set `CORS_ALLOWED_ORIGINS` to include `http://localhost:5173`.

### 4) Environment
- Create a `.env` (not committed) for secrets like DB URL, API keys.

## GitHub

```bash
git init
git add .
git commit -m "Clean structure: backend + frontend"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```

---
Notes:
- Heavy folders like `node_modules`, virtualenvs, and build outputs were intentionally excluded.
- Frontend appears to be JavaScript.
- If something is missing, share details and we can refine.
